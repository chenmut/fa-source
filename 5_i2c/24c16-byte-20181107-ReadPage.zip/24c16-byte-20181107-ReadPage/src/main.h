#ifndef _MAIN_H
#define _MAIN_H
	#include "common/common.h"
	
	#include "driver/24c16.h"
#endif 	//_MAIN_H
