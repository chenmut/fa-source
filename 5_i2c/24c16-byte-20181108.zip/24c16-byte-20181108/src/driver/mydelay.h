#ifndef _MYDELAY_H
#define _MYDELAY_H
	unsigned int delayMicroseconds2Test ( int nTime );
#endif	//_MYDELAY_H
















