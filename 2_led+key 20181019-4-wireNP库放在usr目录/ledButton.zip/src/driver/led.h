#include "../common/common.h"

void ledOn( int pin);
void ledOff( int pin);