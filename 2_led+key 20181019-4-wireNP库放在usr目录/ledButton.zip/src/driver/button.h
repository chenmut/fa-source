#include "../common/common.h"

int getButtonStatus(const int button);