#include "mydelay.h"

//���� nTime us delay
unsigned int delayMicroseconds2Test ( int nTime )
{
	int i = 0, j = 0;
	
	for ( i = 0; i < nTime; i++ )
	{
		for ( j = 0; j < 65; j++  );
	}
	
	return 0;
}



























